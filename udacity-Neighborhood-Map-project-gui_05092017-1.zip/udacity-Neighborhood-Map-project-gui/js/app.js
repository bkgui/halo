//the shopplaces object contains the information for all interesting shop surrounding my neighborhood 
var shopplaces = [
	{
		shop: 'Kek Lok Si',
		lat: 5.398543,
		long: 100.272204,
		addr: '86s,Jalan Balik Pulau,11500 Ayer Itam,Pulau Pinang',
		tel: '6018-493 0852',
		link: 'Kek%20Lok%20Si'
	},
	{
		shop: 'Penang Hill',
		lat: 5.423492,
		long: 100.269882,
		addr: 'Jalan Stesen Bukit Bendera,Air Itam,11500 Pulau Pinang',
		tel: '604-828 8880',
		link: 'Penang%20Hill'
	},
	{
		shop: 'Penang National Park',
		lat: 5.462804,
		long: 100.194839,
		addr: 'Jalan Hassan Abbas, Teluk Bahang,11050 Pulau Pinang',
		tel: '604-881 3530',
		link: 'Penang%20National%20Park'
	},
	{
		shop: 'Snake Temple',
		lat: 5.314249,
		long: 100.284702,
		addr: 'Jalan Sultan Azlan Shah,Bayan Lepas Indust.Park,11900 Bayan Lepas,Pulau Pinang',
		tel: '604-643 7273',
		link: 'Snake%20Temple'
	},
	{
		shop: 'Little India Penang',
		lat: 5.417256,
		long: 100.339082,
		addr: 'Lebuh Pasar,George Town,10200 George Town,Pulau Pinang',
		tel: '604-326 3436',
		link: 'Little%20India%20Penang'
	},
	{
		shop: 'Fort Cornwallis',
		lat: 5.420579,
		long: 100.343877,
		addr: 'Jalan Tun Syed Sheh Barakbah,George Town,10200 George Town,Pulau Pinang',
		tel: '604-216 2810',
		link: 'Fort%20Corwallis'
	},
	{
		shop: 'Khoo Kongsi',
		lat: 5.415141,
		long: 100.336594,
		addr: '18,Cannon Square,George Town,10450 George Town,Pulau Pinang',
		tel: '604-754 8888',
		link: 'Khoo%20Kongsi'
	},
	{
		shop: 'Cenotaph Penang',
		lat: 5.281509,
		long: 100.288755,
		addr: 'Jalan Padang Kota Lama,George Town,10200 George Town,Pulau Pinang',
		tel: '604-988 7773',
		link: 'Cenotaph%20Penang'
	}
];

//the map variable holds the google map element brought from Google map API
var googlemap;

//the Model object that dynamically drive my sidebar and markers with shopmodel knockout observable
var Location = function(data) {
	var self = this;
	this.shop = data.shop;
	this.lat = data.lat;
	this.long = data.long;
	this.addr = data.addr;
	this.tel = data.tel;
	this.link = data.link;

	this.visible = ko.observable(false);
	this.infoWindow = new google.maps.InfoWindow();


	this.marker = new google.maps.Marker({
			position: new google.maps.LatLng(data.lat, data.long),
			googlemap: googlemap,
			animation: google.maps.Animation.DROP,
			title: data.shop
	});

	this.DisplayMarker = ko.computed(function() {
			if(this.visible() === true) {
				this.marker.setMap(googlemap);
			} else {
				this.marker.setMap(null);
			}
			return true;
		}, 		this);


	//the Click function is how I get elements that list out the shops information
	this.marker.addListener('click', function() {
		self.infoWindow.open(googlemap, this);
		self.infoWindow.setContent(self.contentString);

		self.marker.setAnimation(google.maps.Animation.BOUNCE);
      	setTimeout(function() {
      		self.marker.setAnimation(null);
     	}, 2000);


      	//Info taken from Wikipedia API
		var wikiUrl = 'http://en.wikipedia.org/w/api.php?action=opensearch&search=' + data.shop + '&format=json&callback=wikiCallback';

		return $.ajax({
			type: "Get",
	        url: wikiUrl,
	        dataType: "jsonp",
	        jsonp: "callback",
	        async: true,
	    }).done(function(data, textStatus, jqXHR) {
	    	console.log(data);
            var articleList = data[2];
            console.log(articleList);
            var articleStr = self.link;
            console.log(articleStr);
            var url = 'http://en.wikipedia.org/wiki/' + articleStr;
            self.infoWindow.setContent('<div class="info-window-content"><div class="title"><b>' + self.shop + "</b></div>" +
            '<div class="content">' + '<a href=' + url + '><br>Wikipedia: </a>' + articleList + "</div>" +
            '<div class="content">' + '<br>Address: ' + self.addr + "</div>" +
            '<div class="content">' + 'Contact: ' + self.tel + "</div>"
            );

            $('#wikipedia-container').append('<div id="' + data.shop + '"><p style="font-weight: bold"> ' + ' </p><p style="margin: 5px; text-align: center; font-weight: bold"><a style="color: blue" href="' + url + '">' + articleStr + '</a></p></div>');
	    }).fail(function(){
	    	$('#wikipedia-container').append('<div id="' + data.shop + '">Wikipedia Request Timed Out!</div>');
	    });
	});

	this.bounce = function(place) {
		google.maps.event.trigger(self.marker, 'click');
	};
};

function startApp() {
	ko.applyBindings(new CherasModel());
	}

//New map contructor//
function CherasModel() {
	var self = this;

	this.searchRule = ko.observable("");

	this.locationarea = ko.observableArray([]);

	googlemap = new google.maps.Map(document.getElementById('googlemap'), {
		center: {lat: 5.339076, lng: 100.279643},
		zoom: 12
		});
	
	shopplaces.forEach(function(PenangLocation){
		self.locationarea.push( new Location(PenangLocation));
		});

	this.filteredList = ko.computed( function() {
	var filter = self.searchRule().toUpperCase();
	if (!filter) {
		self.locationarea().forEach(function(PenangLocation){
				PenangLocation.visible(true);
		});
		return self.locationarea();
	} else {
		return ko.utils.arrayFilter(self.locationarea(), function(PenangLocation) {
			var string = PenangLocation.shop.toUpperCase();
			var result = (string.search(filter) >= 0);
			PenangLocation.visible(result);
		return result;
		});
		}
	}, self);
}

function errorHandling() {
	alert("Failed to load Google Maps. Please check your internet connection and try again.");
	}