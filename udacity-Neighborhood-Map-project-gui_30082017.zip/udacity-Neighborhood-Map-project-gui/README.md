
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$$$$$ Full Stack Web Developer Project $$$$$
$$$$$	-	Neighborhood Maps     -    $$$$$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


1)DESCRIPTION:
- It is a challenge that put together a website from various APIs which includes making function calls to Google Maps and other location-based services like Wikipedia.
1.1) This map show 8 predefine attractive tourist spot in Penang island at Northern region of Malaysia.
1.2) User have the option to view details of the locations with info from Wikipedia.
1.3) A "MENU" on the left side and also a search box that can display the location and also filter out the MENU items to specific location only.
 

2) PREPARATION:
- References used to develop this map.
2.1) Google Map API
2.2) Wikipedia API  
2.3) HTML and CSS
2.4) JQuery and KnockoutJS 
2.5) Ajax(JSON)


3) HOW TO USE:
3.1) Open the "index.html" file in web browser.
3.2) List of predefined locations show on the left MENU, click any location in the MENU and a bounce red marker will move and display the location info.
3.3) User can also hover the mouse to any red marker, which also display the location name.
3.4) Click on red marker will display the location info and also a link to Wikipedia if user want to know more detail about that location.
3.5) A search box located on the left side bottom, which filter only specific location with red marker point to that location accordingly.


4) References:
- Course material.
- https://stackoverflow.com
- Course forums.
