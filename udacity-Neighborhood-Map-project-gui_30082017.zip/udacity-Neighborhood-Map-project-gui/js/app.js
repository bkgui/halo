//the shopplaces object contains the information for all interesting shop surrounding my neighborhood 
var shopplaces = [
	{
		shop: 'Kek Lok Si',
		lat: 5.398543,
		long: 100.272204,
		addr: '86s,Jalan Balik Pulau,11500 Ayer Itam,Pulau Pinang',
		tel: '6018-493 0852'
	},
	{
		shop: 'Penang Hill',
		lat: 5.423492,
		long: 100.269882,
		addr: 'Jalan Stesen Bukit Bendera,Air Itam,11500 Pulau Pinang',
		tel: '604-828 8880'
	},
	{
		shop: 'Penang National Park',
		lat: 5.462804,
		long: 100.194839,
		addr: 'Jalan Hassan Abbas, Teluk Bahang,11050 Pulau Pinang',
		tel: '604-881 3530'
	},
	{
		shop: 'Snake Temple',
		lat: 5.314249,
		long: 100.284702,
		addr: 'Jalan Sultan Azlan Shah,Bayan Lepas Indust.Park,11900 Bayan Lepas,Pulau Pinang',
		tel: '604-643 7273'
	},
	{
		shop: 'Little India Penang',
		lat: 5.417256,
		long: 100.339082,
		addr: 'Lebuh Pasar,George Town,10200 George Town,Pulau Pinang',
		tel: '604-326 3436'
	},
	{
		shop: 'Fort Cornwallis',
		lat: 5.420579,
		long: 100.343877,
		addr: 'Jalan Tun Syed Sheh Barakbah,George Town,10200 George Town,Pulau Pinang',
		tel: '604-216 2810'
	},
	{
		shop: 'Khoo Kongsi',
		lat: 5.415141,
		long: 100.336594,
		addr: '18,Cannon Square,George Town,10450 George Town,Pulau Pinang',
		tel: '604-754 8888'
	},
	{
		shop: 'Cenotaph Penang',
		lat: 5.281509,
		long: 100.288755,
		addr: 'Jalan Padang Kota Lama,George Town,10200 George Town,Pulau Pinang',
		tel: '604-988 7773'
	}

];

//the map variable holds the google map element brought from Google map API
var googlemap;

//the Model object that dynamically drive my sidebar and markers with shopmodel knockout observable
var Location = function(data) {
	var self = this;
	this.shop = data.shop;
	this.lat = data.lat;
	this.long = data.long;
	this.addr = data.addr;
	this.tel = data.tel;

	this.visible = ko.observable(false);

	// this.contentString = '<div class="info-window-content"><div class="title"><b>' + data.shop + "</b></div>" +
 //        '<div class="content">' + self.addr + "</div>" +
 //        '<div class="content">' + self.tel + "</div></div>";

	this.infoWindow = new google.maps.InfoWindow({content: self.contentString});

	this.marker = new google.maps.Marker({
			position: new google.maps.LatLng(data.lat, data.long),
			googlemap: googlemap,
			animation: google.maps.Animation.DROP,
			title: data.shop
	});

	this.DisplayMarker = ko.computed(function() {
			if(this.visible() === true) {
				this.marker.setMap(googlemap);
			} else {
				this.marker.setMap(null);
			}
			return true;
		}, 		this);

	//the Click function is how I get elements that list out the shops information
	this.marker.addListener('click', function(){
		self.contentString = '<div class="info-window-content"><div class="title"><b>' + data.shop + "</b></div>" +
        '<div class="content">' + 'ADDRESS: '  + self.addr + "</div>" +
        '<div class="content">' + 'CONTACT: ' + self.tel + "</div></div>";

        self.infoWindow.setContent(self.contentString);

		self.infoWindow.open(googlemap, this);

		self.marker.setAnimation(google.maps.Animation.BOUNCE);
      	setTimeout(function() {
      		self.marker.setAnimation(null);
     	}, 2000);


var markers = [];

//clear markers before starting new search 
    function clearLocations() {
        infoWindow = new google.maps.InfoWindow();
        infoWindow.close();
            for (var i = 0; i < markers.length; i++) {
                markers[i].setMap(null);
            }
            markers.length = 0;
        }
 
    function searchLocationsNear(center) {

  	//call clrear markers
    clearLocations();
    	}


      	//Info taken from Wikipedia API
		var wikiUrl = 'http://en.wikipedia.org/w/api.php?action=opensearch&search=' + data.shop + '&format=json&callback=wikiCallback';

		return $.ajax({
	        url: wikiUrl,
	        dataType: "jsonp",
	        jsonp: "callback",
	        async: true,
	    }).done(function(data, textStatus, jqXHR) {
	    	console.log(data);
            var articleList = data[1];
            console.log(articleList);
            var articleStr = articleList[1];
            console.log(articleStr);
            var url = 'http://en.wikipedia.org/wiki/' + articleStr;
            $('#wikipedia-container').append('<div id="' + data.shop + '"><p style="font-weight: bold">' + ' nice places!</p><p style="margin: 5px; text-align: center; font-weight: bold"><a style="color: blue" href="' + url + '">' + articleStr + '</a></p><p style="font-weight: bold">More detail,Check on Wikipedia :)</p></div>');
	    }).fail(function(){
	    	$('#wikipedia-container').append('<div id="' + data.shop + '">Apologies the wiki request timed out</div>');
	    });

	//  //remove old markers from array
	// marker = [];

	});

	this.bounce = function(place) {
		google.maps.event.trigger(self.marker, 'click');
	};
};





function startApp() {
	ko.applyBindings(new CherasModel());
	}

//New map contructor//
function CherasModel() {
	var self = this;

	this.searchRule = ko.observable("");

	this.locationarea = ko.observableArray([]);

	googlemap = new google.maps.Map(document.getElementById('googlemap'), {
		center: {lat: 5.339076, lng: 100.279643},
		zoom: 12
		});
	
	shopplaces.forEach(function(PenangLocation){
		self.locationarea.push( new Location(PenangLocation));
		});

	this.filteredList = ko.computed( function() {
	var filter = self.searchRule().toUpperCase();
	if (!filter) {
		self.locationarea().forEach(function(PenangLocation){
				PenangLocation.visible(true);
		});
		return self.locationarea();
	} else {
		return ko.utils.arrayFilter(self.locationarea(), function(PenangLocation) {
			var string = PenangLocation.shop.toUpperCase();
			var result = (string.search(filter) >= 0);
			PenangLocation.visible(result);
		return result;
		});
		}
	}, self);
}

function errorHandling() {
	alert("Failed to load Google Maps. Please check your internet connection and try again.");
	}